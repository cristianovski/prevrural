import { useState, useEffect, useRef } from "react";
import { 
  ArrowLeft, Search, Plus, FileText, 
  Image as ImageIcon, Calendar, Trash2, Eye, 
  Download, Edit2, AlertCircle, Save, Scale, UploadCloud, Folder, X, Check, ChevronDown, MessageSquare
} from "lucide-react";
import { supabase } from "../../lib/supabase";

// --- BASE DE CONHECIMENTO JURÍDICO ---
const LEGAL_BASIS: Record<string, { law: string, obs: string }> = {
  "Autodeclaração do Segurado Especial": { law: "Lei 8.213/91, Art. 38-B, § 2º; IN 128/2022, Art. 115", obs: "Principal para períodos anteriores a 2023. Deve ser ratificada por bases governamentais." },
  "Bloco de Notas do Produtor Rural": { law: "Lei 8.213/91, Art. 106, V; IN 128/2022, Art. 116, III", obs: "Prova robusta de comercialização e atividade ativa." },
  "Carta de Concessão de Benefício Anterior": { law: "IN 128/2022, Art. 115 e 116; Portaria 993/2022", obs: "Prova plena para o período em que o benefício (auxílio/maternidade) foi recebido." },
  "Carteira de Vacinação": { law: "IN 128/2022, Art. 116, XXV", obs: "Prova residência rural e acompanhamento por agentes locais. Fundamental para crianças/mães." },
  "Certidão da FUNAI (Indígena)": { law: "IN 128/2022, Art. 116, X; Súmula 657 STJ", obs: "Substitui autodeclaração para indígenas." },
  "Certidão da Justiça Eleitoral": { law: "PUIL 0006786-13.2011.4.01.4300", obs: "Certidão que consta a profissão declarada no cadastro eleitoral como lavrador." },
  "Certidão de Casamento/União Estável": { law: "IN 128/2022, Art. 116, XI; Súmula 6 TNU", obs: "Estende a profissão do cônjuge. Deve ser contemporânea ao período pedido." },
  "Certidão de Nascimento/Batismo Filhos": { law: "IN 128/2022, Art. 116, XII", obs: "Fixa a presença da família no meio rural em datas específicas." },
  "Certidão de Óbito de Familiares": { law: "STJ (Jurisprudência em Teses Ed. 94)", obs: "Óbito de parente constando lavrador/sítio serve como indício." },
  "Certificado de Alistamento Militar": { law: "IN 128/2022, Art. 116, XVI", obs: "Geralmente contém a profissão declarada pelo jovem (ex: lavrador)." },
  "Comprovantes de Recolhimento (GPS)": { law: "Lei 8.213/91, Art. 106, VIII", obs: "Se houver recolhimento facultativo ou por comercialização." },
  "Contratos Agrários (Arrendamento/Parceria)": { law: "Lei 8.213/91, Art. 106, II; IN 128/2022, Art. 116, I", obs: "Validade a partir do registro/reconhecimento de firma. Segurado deve ser o outorgado." },
  "DAP ou CAF (Pronaf)": { law: "Lei 8.213/91, Art. 106, IV; IN 128/2022, Art. 116, II", obs: "Forte instrumento ratificador. O INSS consulta o 'InfoDAP' para validar." },
  "Declaração de Imposto de Renda (IRPF)": { law: "Lei 8.213/91, Art. 106, IX; IN 128/2022, Art. 116, VII", obs: "Deve conter renda de comercialização rural declarada." },
  "Documentos do 'Pater Familiae'": { law: "Súmula 73 TRF4; Enunciado 8, V do CRPS", obs: "Documentos do cônjuge/pai servem como prova emprestada para todo o grupo familiar." },
  "Documentos Escolares": { law: "IN 128/2022, Art. 116, XVII", obs: "Escola rural ou ficha de matrícula indicando profissão dos pais como lavradores." },
  "Escritura Pública de Imóvel": { law: "IN 128/2022, Art. 116, XXI", obs: "Prova propriedade. Analisar com autodeclaração." },
  "Ficha de Atendimento Médico/Odontológico": { law: "IN 128/2022, Art. 116, XXXV", obs: "Fichas de postos (PSF) indicando profissão ou residência em zona rural." },
  "Ficha de Crediário (Comércio/Insumos)": { law: "Manual Aposentadoria Rural; IN 128/2022, Art. 116, XXVII", obs: "Cadastros em lojas de ferragens/veterinárias descrevendo o cliente como agricultor." },
  "Ficha de Sindicato / Cooperativa": { law: "IN 128/2022, Art. 116, XVIII e XXIX", obs: "Ficha de filiação antiga ou recibos servem como início de prova." },
  "ITR ou CCIR": { law: "IN 128/2022, Art. 116, IX; Tema 1115 STJ", obs: "Comprova posse da terra. Tamanho > 4 módulos não descaracteriza se houver economia familiar." },
  "Licença de Ocupação / Permissão INCRA": { law: "Lei 8.213/91, Art. 106, X; IN 128/2022, Art. 116, VIII", obs: "Documento específico para assentados da reforma agrária." },
  "Notas Fiscais de Entrada": { law: "Lei 8.213/91, Art. 106, VI; IN 128/2022, Art. 116, IV", obs: "Emitidas pela empresa compradora. Segurado deve constar como vendedor." },
  "Prontuário Médico / Ficha Agente Saúde": { law: "IN 128/2022, Art. 116, XXIV; TNU PEDILEF", obs: "Histórico do Agente de Saúde comprova visitação e residência contínua." },
  "Publicação na Imprensa": { law: "IN 128/2022, Art. 116, XXXI", obs: "Menções em jornais sobre colheitas, festas rurais ou premiações." },
  "Recibo de Compra de Insumos/Implementos": { law: "IN 128/2022, Art. 116, XXVII", obs: "Comprova investimento na produção (sementes, adubo, ferramentas)." },
  "Recibo de Vacina (Febre Aftosa)": { law: "IN 128/2022, Art. 116, XXVII", obs: "Prova de atividade pecuária ativa naquele ano." },
  "Registro em Livros Religiosos (Sacramentos)": { law: "IN 128/2022, Art. 116, XXXII", obs: "Batismo/Crisma citando a localidade rural ou profissão dos pais." },
  "Título de Eleitor (Ficha Cadastro)": { law: "IN 128/2022, Art. 116, XV", obs: "Deve constar a profissão declarada como agricultor/lavrador na época." }
};

interface UnifiedDoc {
  id: string;
  uid: string; 
  title: string;
  type: string; // Categoria
  issueDate: string;
  url: string;
  source: 'Ficha Rural' | 'Cadastro Cliente' | 'GED';
  originalRef?: any;
  userObs?: string; // Campo de observação livre
  legal?: { law: string, obs: string };
}

interface PageProps {
  cliente: any;
  onBack: () => void;
}

export function ClientDocumentsManager({ cliente, onBack }: PageProps) {
  const [loading, setLoading] = useState(true);
  const [docs, setDocs] = useState<UnifiedDoc[]>([]);
  const [filter, setFilter] = useState("Todos");
  const [searchTerm, setSearchTerm] = useState("");
  
  // Estado para Edição/Visualização Lateral
  const [selectedDoc, setSelectedDoc] = useState<UnifiedDoc | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({ 
    title: "", 
    customTitle: "", 
    issueDate: "", 
    type: "", 
    userObs: "" 
  });
  const [saving, setSaving] = useState(false);

  // Estados para Upload
  const [uploading, setUploading] = useState(false);
  const [fileToUpload, setFileToUpload] = useState<File | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  
  // Metadados do Upload
  const [uploadMetadata, setUploadMetadata] = useState({ 
    category: "Provas", 
    docType: "", // Seleção do Dropdown
    customName: "", // Texto livre se for 'Outros'
    date: new Date().toISOString().split('T')[0],
    userObs: ""
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (cliente?.id) loadAllDocuments();
  }, [cliente]);

  const loadAllDocuments = async () => {
    setLoading(true);
    const combinedDocs: UnifiedDoc[] = [];

    try {
      // 1. BUSCAR DO CADASTRO (CLIENTS.PERSONAL_DOCS)
      const { data: clientData } = await supabase.from('clients').select('personal_docs').eq('id', cliente.id).single();
      
      if (clientData?.personal_docs && Array.isArray(clientData.personal_docs)) {
        clientData.personal_docs.forEach((doc: any, idx: number) => {
          const docName = doc.name || "Documento Pessoal";
          const legalData = LEGAL_BASIS[docName];
          const cat = doc.category || "Pessoal";

          combinedDocs.push({
            id: `personal-${idx}`,
            uid: `personal-${idx}-${Date.now()}`,
            title: docName,
            type: cat,
            issueDate: doc.issueDate || new Date().toISOString().split('T')[0],
            url: doc.url,
            userObs: doc.userObs || "",
            source: 'Cadastro Cliente',
            originalRef: doc,
            legal: legalData
          });
        });
      }

      // 2. BUSCAR DA FICHA RURAL (INTERVIEWS.TIMELINE_JSON)
      const { data: interview } = await supabase
        .from('interviews')
        .select('timeline_json')
        .eq('client_id', cliente.id)
        .maybeSingle();

      if (interview?.timeline_json && Array.isArray(interview.timeline_json)) {
        interview.timeline_json.forEach((doc: any, idx: number) => {
          let date = doc.issueDate;
          if (!date && doc.year) date = `${doc.year}-01-01`;
          if (!date) date = "S/D";

          const docName = doc.type || "Prova Rural";
          const legalData = LEGAL_BASIS[docName];
          // Se não tiver categoria salva, assume Provas
          const cat = doc.category || "Provas";

          combinedDocs.push({
            id: doc.id || `rural-idx-${idx}`, // Garante ID
            uid: `rural-${doc.id || idx}`,
            title: docName,
            type: cat,
            issueDate: date,
            url: doc.fileUrl,
            userObs: doc.userObs || "",
            source: 'Ficha Rural',
            originalRef: doc,
            legal: legalData
          });
        });
      }

      // 3. BUSCAR DA NOVA TABELA (CLIENT_DOCUMENTS) - FUTURO
      const { data: newDocs } = await supabase
        .from('client_documents')
        .select('*')
        .eq('client_id', cliente.id);

      if (newDocs) {
        newDocs.forEach((doc: any) => {
          const docName = doc.original_name || "Documento";
          const legalData = LEGAL_BASIS[docName];

          combinedDocs.push({
            id: doc.id,
            uid: `ged-${doc.id}`,
            title: docName,
            type: doc.category || "Diversos",
            issueDate: doc.reference_date || doc.created_at.split('T')[0],
            url: doc.file_url,
            userObs: doc.observations || "",
            source: 'GED',
            originalRef: doc,
            legal: legalData
          });
        });
      }

      // Ordenar por data
      combinedDocs.sort((a, b) => {
        const dateA = a.issueDate === 'S/D' ? '1900-01-01' : a.issueDate;
        const dateB = b.issueDate === 'S/D' ? '1900-01-01' : b.issueDate;
        return new Date(dateB).getTime() - new Date(dateA).getTime();
      });

      setDocs(combinedDocs);

    } catch (error) {
      console.error("Erro ao carregar documentos:", error);
    } finally {
      setLoading(false);
    }
  };

  // --- FLUXO DE UPLOAD ---
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setFileToUpload(file);
    setUploadMetadata({
      category: "Provas",
      docType: "", 
      customName: file.name.split('.')[0], 
      date: new Date().toISOString().split('T')[0],
      userObs: ""
    });
    setIsUploadModalOpen(true);
    e.target.value = ""; 
  };

  const confirmUpload = async () => {
    if (!fileToUpload) return;
    
    // Determinar o nome final
    let finalName = uploadMetadata.docType;
    if (!finalName || finalName === "Outros") {
        if (!uploadMetadata.customName.trim()) return alert("Por favor, digite o nome do documento.");
        finalName = uploadMetadata.customName;
    }

    setUploading(true);

    try {
        const fileExt = fileToUpload.name.split('.').pop();
        const cleanName = finalName.replace(/[^a-zA-Z0-9]/g, '_');
        const fileName = `${cliente.id}/ged_${Date.now()}_${cleanName}.${fileExt}`;

        // 1. Upload Físico
        const { error: uploadError } = await supabase.storage
            .from('evidence-files')
            .upload(fileName, fileToUpload);

        if (uploadError) throw uploadError;

        const { data: { publicUrl } } = supabase.storage
            .from('evidence-files')
            .getPublicUrl(fileName);

        // 2. Salvar Metadados (Salvando no array 'personal_docs' para unificar)
        const { data: clientData } = await supabase.from('clients').select('personal_docs').eq('id', cliente.id).single();
        const currentDocs = clientData?.personal_docs || [];
        
        const newDoc = {
            name: finalName,
            url: publicUrl,
            category: uploadMetadata.category, 
            issueDate: uploadMetadata.date,
            userObs: uploadMetadata.userObs,
            uploadDate: new Date().toISOString()
        };

        const { error: dbError } = await supabase
            .from('clients')
            .update({ personal_docs: [...currentDocs, newDoc] })
            .eq('id', cliente.id);

        if (dbError) throw dbError;

        alert("Documento salvo com sucesso!");
        setIsUploadModalOpen(false);
        setFileToUpload(null);
        loadAllDocuments(); 

    } catch (error: any) {
        alert("Erro no upload: " + error.message);
    } finally {
        setUploading(false);
    }
  };

  const handleSelectDoc = (doc: UnifiedDoc) => {
    setSelectedDoc(doc);
    
    // Configura o formulário de edição
    const isStandard = Object.keys(LEGAL_BASIS).includes(doc.title);
    setEditForm({ 
        title: isStandard ? doc.title : "Outros", 
        customTitle: isStandard ? "" : doc.title, 
        issueDate: doc.issueDate === 'S/D' ? '' : doc.issueDate, 
        type: doc.type,
        userObs: doc.userObs || ""
    });
    
    setIsEditing(false);
  };

  const handleSaveEdits = async () => {
      if (!selectedDoc) return;
      setSaving(true);

      let finalName = editForm.title;
      if (finalName === "Outros") {
          if (!editForm.customTitle.trim()) {
              setSaving(false);
              return alert("Digite o nome personalizado.");
          }
          finalName = editForm.customTitle;
      }

      try {
          if (selectedDoc.source === 'Cadastro Cliente') {
              // Busca o array mais recente
              const { data: clientData } = await supabase.from('clients').select('personal_docs').eq('id', cliente.id).single();
              if (clientData?.personal_docs) {
                  // Mapeia usando a URL como chave, que é única
                  const updatedDocs = clientData.personal_docs.map((d: any) => {
                      if (d.url === selectedDoc.url) {
                          return { 
                              ...d, 
                              name: finalName, 
                              category: editForm.type,
                              issueDate: editForm.issueDate,
                              userObs: editForm.userObs
                          };
                      }
                      return d;
                  });
                  await supabase.from('clients').update({ personal_docs: updatedDocs }).eq('id', cliente.id);
              }
          } 
          else if (selectedDoc.source === 'Ficha Rural') {
              const { data: interview } = await supabase.from('interviews').select('timeline_json').eq('client_id', cliente.id).single();
              if (interview?.timeline_json) {
                  // Aqui usamos a URL ou o ID original para encontrar o item
                  const updatedTimeline = interview.timeline_json.map((d: any) => {
                      const matchById = d.id && d.id === selectedDoc.originalRef.id;
                      const matchByUrl = d.fileUrl && d.fileUrl === selectedDoc.url;
                      
                      if (matchById || matchByUrl) { 
                          return { 
                              ...d, 
                              type: finalName, 
                              category: editForm.type, // ADICIONA CATEGORIA EXPLICITA
                              issueDate: editForm.issueDate,
                              userObs: editForm.userObs
                          };
                      }
                      return d;
                  });
                  await supabase.from('interviews').update({ timeline_json: updatedTimeline }).eq('client_id', cliente.id);
              }
          }
          else if (selectedDoc.source === 'GED') {
              await supabase.from('client_documents').update({
                  original_name: finalName,
                  category: editForm.type,
                  reference_date: editForm.issueDate,
                  observations: editForm.userObs
              }).eq('id', selectedDoc.id);
          }

          alert("Documento atualizado!");
          setIsEditing(false);
          
          // Atualiza estado local imediatamente
          const newLegal = LEGAL_BASIS[finalName];
          setSelectedDoc(prev => prev ? ({ 
              ...prev, 
              title: finalName, 
              issueDate: editForm.issueDate, 
              type: editForm.type,
              userObs: editForm.userObs,
              legal: newLegal 
          }) : null);
          
          loadAllDocuments();

      } catch (err: any) {
          alert("Erro ao salvar edição: " + err.message);
      } finally {
          setSaving(false);
      }
  };

  const handleDeleteDoc = async () => {
      if (!selectedDoc) return;
      if (!confirm("Tem certeza que deseja excluir este documento? Esta ação não pode ser desfeita.")) return;
      setSaving(true);

      try {
          if (selectedDoc.source === 'Cadastro Cliente') {
              const { data: clientData } = await supabase.from('clients').select('personal_docs').eq('id', cliente.id).single();
              if (clientData?.personal_docs) {
                  const updatedDocs = clientData.personal_docs.filter((d: any) => d.url !== selectedDoc.url);
                  await supabase.from('clients').update({ personal_docs: updatedDocs }).eq('id', cliente.id);
              }
          }
          else if (selectedDoc.source === 'Ficha Rural') {
              const { data: interview } = await supabase.from('interviews').select('timeline_json').eq('client_id', cliente.id).single();
              if (interview?.timeline_json) {
                  const updatedTimeline = interview.timeline_json.filter((d: any) => {
                      if (d.id && d.id === selectedDoc.originalRef.id) return false;
                      if (d.fileUrl && d.fileUrl === selectedDoc.url) return false;
                      return true;
                  });
                  await supabase.from('interviews').update({ timeline_json: updatedTimeline }).eq('client_id', cliente.id);
              }
          }
          else if (selectedDoc.source === 'GED') {
              await supabase.from('client_documents').delete().eq('id', selectedDoc.id);
          }

          alert("Documento excluído.");
          setSelectedDoc(null);
          loadAllDocuments();

      } catch (err: any) {
          alert("Erro ao excluir: " + err.message);
      } finally {
          setSaving(false);
      }
  };

  const filteredDocs = docs.filter(doc => {
      const matchesSearch = doc.title.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesFilter = filter === "Todos" || doc.type === filter;
      return matchesSearch && matchesFilter;
  });

  const getFileIcon = (url: string) => {
      if (!url) return <AlertCircle className="text-red-400" />;
      if (url.toLowerCase().endsWith('.pdf')) return <FileText className="text-red-500" />;
      return <ImageIcon className="text-blue-500" />;
  };

  const formatDate = (date: string) => {
      if (!date || date === 'S/D') return "Sem Data";
      return new Date(date).toLocaleDateString('pt-BR');
  };

  return (
    <div className="flex flex-col h-full bg-slate-100 font-sans">
      {/* HEADER */}
      <header className="bg-white border-b border-slate-200 p-4 flex justify-between items-center sticky top-0 z-20 shadow-sm">
        <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition text-slate-500">
                <ArrowLeft size={20}/>
            </button>
            <div>
                <h1 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                    Gestão de Documentos (GED)
                </h1>
                <p className="text-xs text-slate-500">Centralizando {docs.length} provas de {cliente.nome}</p>
            </div>
        </div>
        
        <div className="flex gap-2">
            <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                onChange={handleFileSelect} 
                disabled={uploading}
            />
            <button 
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg font-bold text-sm shadow flex items-center gap-2 transition-all disabled:opacity-50"
            >
                {uploading ? <UploadCloud className="animate-bounce" size={16}/> : <Plus size={16}/>}
                {uploading ? "Enviando..." : "Novo Upload"}
            </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        
        {/* ESQUERDA: LISTA DE ARQUIVOS */}
        <div className={`flex-1 flex flex-col min-w-0 transition-all ${selectedDoc ? 'w-3/5' : 'w-full'}`}>
            
            {/* FILTROS */}
            <div className="p-4 bg-white border-b border-slate-200 flex flex-col md:flex-row gap-3">
                <div className="relative flex-1">
                    <Search className="absolute left-3 top-2.5 text-slate-400" size={18}/>
                    <input 
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                        placeholder="Buscar por nome, tipo..."
                        className="w-full pl-10 pr-4 py-2 bg-slate-100 border-transparent focus:bg-white focus:border-emerald-500 border rounded-lg text-sm outline-none transition-all"
                    />
                </div>
                <div className="flex gap-2 overflow-x-auto">
                    {["Todos", "Provas", "Pessoal", "Diversos"].map(f => (
                        <button 
                            key={f} 
                            onClick={() => setFilter(f)}
                            className={`px-4 py-2 rounded-lg text-xs font-bold whitespace-nowrap transition-colors ${filter === f ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'}`}
                        >
                            {f}
                        </button>
                    ))}
                </div>
            </div>

            {/* LISTAGEM */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-slate-50">
                {loading ? (
                    <div className="text-center py-20 text-slate-400">Carregando central...</div>
                ) : filteredDocs.length === 0 ? (
                    <div className="text-center py-20 border-2 border-dashed border-slate-200 rounded-xl m-4">
                        <Folder className="mx-auto text-slate-300 mb-2" size={40}/>
                        <p className="text-slate-500 font-medium">Nenhum documento encontrado.</p>
                    </div>
                ) : (
                    filteredDocs.map((doc) => (
                        <div 
                            key={doc.uid} 
                            onClick={() => handleSelectDoc(doc)}
                            className={`group flex items-start gap-4 p-4 rounded-xl border cursor-pointer transition-all hover:shadow-md ${selectedDoc?.uid === doc.uid ? 'bg-blue-50 border-blue-300 ring-1 ring-blue-200' : 'bg-white border-slate-200 hover:border-emerald-300'}`}
                        >
                            <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center shrink-0 group-hover:bg-white transition-colors mt-1">
                                {getFileIcon(doc.url)}
                            </div>
                            
                            <div className="flex-1 min-w-0">
                                <h4 className={`font-bold text-sm truncate ${selectedDoc?.uid === doc.uid ? 'text-blue-900' : 'text-slate-800'}`}>
                                    {doc.title}
                                </h4>
                                
                                {/* FUNDAMENTAÇÃO LEGAL AUTOMÁTICA */}
                                {(doc.legal || LEGAL_BASIS[doc.title]) && (
                                    <div className="mt-1.5 mb-2 bg-slate-50 p-2 rounded border border-slate-100 text-[10px] text-slate-600 leading-relaxed">
                                        <div className="font-bold text-emerald-700 flex items-center gap-1 mb-0.5"><Scale size={10}/> {(doc.legal || LEGAL_BASIS[doc.title]).law}</div>
                                        <div>{(doc.legal || LEGAL_BASIS[doc.title]).obs}</div>
                                    </div>
                                )}

                                <div className="flex items-center gap-2 mt-1">
                                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium border ${doc.type === 'Provas' || doc.type === 'Rural' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' : doc.type === 'Pessoal' ? 'bg-purple-50 text-purple-700 border-purple-100' : 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                                        {doc.type === 'Rural' ? 'Provas' : doc.type}
                                    </span>
                                    <span className="text-xs text-slate-400 flex items-center gap-1">
                                        <Calendar size={10}/> {formatDate(doc.issueDate)}
                                    </span>
                                </div>
                            </div>

                            <div className="text-right hidden sm:block">
                                <span className="text-[10px] text-slate-400 font-medium uppercase tracking-wider block mb-1">Origem</span>
                                <span className="text-xs font-medium text-slate-600 bg-slate-100 px-2 py-1 rounded">{doc.source}</span>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>

        {/* DIREITA: DETALHES E PREVIEW */}
        {selectedDoc && (
            <aside className="w-[450px] bg-white border-l border-slate-200 flex flex-col shadow-xl z-10 animate-in slide-in-from-right duration-300">
                <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                    <h3 className="font-bold text-slate-700 text-sm">Detalhes do Arquivo</h3>
                    <button onClick={() => setSelectedDoc(null)} className="text-slate-400 hover:text-slate-600"><ArrowLeft size={18}/></button>
                </div>

                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                    {/* PREVIEW ÁREA */}
                    <div className="aspect-[3/4] bg-slate-100 rounded-xl border border-slate-200 flex items-center justify-center overflow-hidden relative group">
                        {selectedDoc.url ? (
                            selectedDoc.url.toLowerCase().endsWith('.pdf') ? (
                                <iframe src={selectedDoc.url} className="w-full h-full" title="Preview" />
                            ) : (
                                <img src={selectedDoc.url} alt="Preview" className="w-full h-full object-contain" />
                            )
                        ) : (
                            <div className="text-center text-slate-400">
                                <AlertCircle size={32} className="mx-auto mb-2 opacity-50"/>
                                <span className="text-xs">Visualização indisponível</span>
                            </div>
                        )}
                        
                        {/* Overlay de Ações */}
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 backdrop-blur-sm">
                            <a href={selectedDoc.url} target="_blank" rel="noreferrer" className="p-3 bg-white rounded-full text-slate-800 hover:text-blue-600 hover:scale-110 transition-all shadow-lg" title="Abrir Original">
                                <Eye size={20}/>
                            </a>
                            <a href={selectedDoc.url} download className="p-3 bg-white rounded-full text-slate-800 hover:text-emerald-600 hover:scale-110 transition-all shadow-lg" title="Baixar">
                                <Download size={20}/>
                            </a>
                        </div>
                    </div>

                    {/* METADADOS EDITÁVEIS */}
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Metadados</h4>
                            {!isEditing ? (
                                <button onClick={() => setIsEditing(true)} className="text-xs flex items-center gap-1 text-blue-600 hover:underline font-bold">
                                    <Edit2 size={12}/> Editar
                                </button>
                            ) : (
                                <button onClick={handleSaveEdits} disabled={saving} className="text-xs flex items-center gap-1 text-emerald-600 hover:underline font-bold">
                                    <Save size={12}/> {saving ? 'Salvando...' : 'Salvar'}
                                </button>
                            )}
                        </div>

                        <div className="space-y-3">
                            <div>
                                <label className="text-xs font-bold text-slate-600 mb-1 block">Nome do Documento</label>
                                <div className="relative">
                                    <select 
                                        disabled={!isEditing}
                                        value={editForm.title}
                                        onChange={e => setEditForm({...editForm, title: e.target.value})}
                                        className="w-full p-2 border border-slate-200 rounded-lg text-sm bg-white focus:border-blue-500 outline-none disabled:bg-slate-50 disabled:text-slate-500 appearance-none"
                                    >
                                        <option value="">Selecione...</option>
                                        {Object.keys(LEGAL_BASIS).map((key, i) => <option key={i} value={key}>{key}</option>)}
                                        <option value="Outros">Outros (Personalizado)</option>
                                    </select>
                                    <ChevronDown size={14} className="absolute right-3 top-3 text-slate-400 pointer-events-none"/>
                                </div>
                                
                                {editForm.title === "Outros" && (
                                    <input 
                                        disabled={!isEditing}
                                        placeholder="Digite o nome do documento..."
                                        value={editForm.customTitle}
                                        onChange={e => setEditForm({...editForm, customTitle: e.target.value})}
                                        className="w-full p-2 mt-2 border border-slate-200 rounded-lg text-sm bg-white focus:border-blue-500 outline-none disabled:bg-slate-50 disabled:text-slate-500"
                                    />
                                )}
                            </div>
                            
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className="text-xs font-bold text-slate-600 mb-1 block">Data Competência</label>
                                    <input 
                                        type="date"
                                        disabled={!isEditing}
                                        value={editForm.issueDate}
                                        onChange={e => setEditForm({...editForm, issueDate: e.target.value})}
                                        className="w-full p-2 border border-slate-200 rounded-lg text-sm bg-white focus:border-blue-500 outline-none disabled:bg-slate-50 disabled:text-slate-500"
                                    />
                                </div>
                                <div>
                                    <label className="text-xs font-bold text-slate-600 mb-1 block">Categoria</label>
                                    <select 
                                        disabled={!isEditing}
                                        value={editForm.type}
                                        onChange={e => setEditForm({...editForm, type: e.target.value})}
                                        className="w-full p-2 border border-slate-200 rounded-lg text-sm bg-white focus:border-blue-500 outline-none disabled:bg-slate-50 disabled:text-slate-500"
                                    >
                                        <option value="Provas">Provas (Rural)</option>
                                        <option value="Pessoal">Pessoal</option>
                                        <option value="Diversos">Diversos</option>
                                    </select>
                                </div>
                            </div>
                            
                            <div>
                                <label className="text-xs font-bold text-slate-600 mb-1 block">Observações / Notas</label>
                                <textarea
                                    disabled={!isEditing}
                                    value={editForm.userObs}
                                    onChange={e => setEditForm({...editForm, userObs: e.target.value})}
                                    placeholder="Detalhes sobre o documento..."
                                    rows={3}
                                    className="w-full p-2 border border-slate-200 rounded-lg text-sm bg-white focus:border-blue-500 outline-none disabled:bg-slate-50 disabled:text-slate-500 resize-none"
                                />
                            </div>

                            {/* EXIBIÇÃO DE LEI NO PAINEL LATERAL TAMBÉM */}
                            {selectedDoc.legal && (
                                <div className="mt-2 bg-blue-50 p-3 rounded-xl border border-blue-100">
                                    <h5 className="font-bold text-blue-800 text-xs mb-2 flex items-center gap-1"><Scale size={12}/> Fundamentação Jurídica</h5>
                                    <p className="text-xs text-blue-900 font-medium mb-1">{selectedDoc.legal.law}</p>
                                    <p className="text-xs text-blue-700 italic opacity-80">{selectedDoc.legal.obs}</p>
                                </div>
                            )}

                            <div className="pt-2">
                                <div className="text-[10px] text-slate-400 mb-1">Fonte original: <span className="font-mono text-slate-600">{selectedDoc.source}</span></div>
                                {selectedDoc.issueDate === 'S/D' && (
                                    <div className="flex items-center gap-2 p-2 bg-amber-50 text-amber-800 text-xs rounded border border-amber-100">
                                        <AlertCircle size={14} className="shrink-0"/>
                                        <span>Data indefinida. Corrija para organizar a linha do tempo.</span>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="p-4 border-t bg-slate-50">
                    <button onClick={handleDeleteDoc} disabled={saving} className="w-full py-3 rounded-xl border border-red-200 text-red-600 font-bold text-sm hover:bg-red-50 flex items-center justify-center gap-2 transition-colors">
                        <Trash2 size={16}/> Excluir Documento
                    </button>
                </div>
            </aside>
        )}
      </div>

      {/* MODAL DE UPLOAD */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-in fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
                <div className="bg-slate-900 p-4 text-white flex justify-between items-center">
                    <h3 className="font-bold flex items-center gap-2"><UploadCloud size={20}/> Novo Upload</h3>
                    <button onClick={() => setIsUploadModalOpen(false)} className="hover:text-red-400 transition"><X size={20}/></button>
                </div>
                
                <div className="p-6 space-y-4">
                    <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center gap-3">
                        <div className="bg-white p-2 rounded-lg border border-slate-200"><FileText size={20} className="text-slate-500"/></div>
                        <div className="flex-1 min-w-0">
                            <p className="text-xs text-slate-500 font-bold uppercase">Arquivo Selecionado</p>
                            <p className="text-sm font-medium truncate text-slate-800">{fileToUpload?.name}</p>
                        </div>
                    </div>

                    <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Nome do Documento</label>
                        <div className="relative">
                            <select 
                                value={uploadMetadata.docType} 
                                onChange={e => setUploadMetadata({...uploadMetadata, docType: e.target.value})} 
                                className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-sm font-medium appearance-none"
                            >
                                <option value="">-- Selecione o Tipo --</option>
                                {Object.keys(LEGAL_BASIS).map((key, i) => <option key={i} value={key}>{key}</option>)}
                                <option value="Outros">Outros (Personalizado)</option>
                            </select>
                            <ChevronDown size={16} className="absolute right-3 top-3.5 text-slate-400 pointer-events-none"/>
                        </div>

                        {uploadMetadata.docType === "Outros" && (
                            <input 
                                value={uploadMetadata.customName} 
                                onChange={e => setUploadMetadata({...uploadMetadata, customName: e.target.value})} 
                                className="w-full mt-2 p-3 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-sm font-medium"
                                placeholder="Digite o nome..."
                                autoFocus
                            />
                        )}
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Categoria</label>
                            <select 
                                value={uploadMetadata.category} 
                                onChange={e => setUploadMetadata({...uploadMetadata, category: e.target.value})} 
                                className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-sm bg-white"
                            >
                                <option value="Provas">Provas</option>
                                <option value="Pessoal">Pessoal</option>
                                <option value="Diversos">Diversos</option>
                            </select>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase mb-1 block">Data Competência</label>
                            <input 
                                type="date"
                                value={uploadMetadata.date} 
                                onChange={e => setUploadMetadata({...uploadMetadata, date: e.target.value})} 
                                className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-sm"
                            />
                        </div>
                    </div>
                    
                    <div>
                        <label className="text-xs font-bold text-slate-500 uppercase mb-1 flex items-center gap-1"><MessageSquare size={12}/> Observações (Opcional)</label>
                        <textarea 
                            value={uploadMetadata.userObs} 
                            onChange={e => setUploadMetadata({...uploadMetadata, userObs: e.target.value})} 
                            className="w-full p-3 border border-slate-200 rounded-xl outline-none focus:border-blue-500 text-sm font-medium resize-none"
                            placeholder="Algum detalhe sobre este documento?"
                            rows={2}
                        />
                    </div>
                </div>

                <div className="p-4 bg-slate-50 border-t border-slate-100 flex gap-3 justify-end">
                    <button onClick={() => setIsUploadModalOpen(false)} className="px-4 py-2 text-slate-500 font-bold hover:bg-slate-200 rounded-lg text-sm transition">Cancelar</button>
                    <button onClick={confirmUpload} disabled={uploading} className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-sm shadow-lg flex items-center gap-2 transition disabled:opacity-50">
                        {uploading ? "Enviando..." : <><Check size={16}/> Confirmar</>}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
}