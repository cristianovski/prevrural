import { useState, useEffect } from "react";
import { 
  ArrowLeft, Save, User, FileText, MapPin, Phone, 
  AlertTriangle, Users, Briefcase, Shield, PenTool,
  Tractor, LayoutList, ChevronRight, ShoppingBag
} from "lucide-react";
import { supabase } from "../../lib/supabase";

interface ClientFormProps {
  onBack: () => void;
  clienteId: number | null;
  onOpenAnalysis?: (id: number) => void; 
  onOpenVisualTimeline?: (id: number) => void;
}

export function ClientFormPage({ onBack, clienteId }: ClientFormProps) {
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'civil' | 'rural'>('civil');
  const [idade, setIdade] = useState<number | null>(null);
  
  // --- ESTADO 1: DADOS CIVIS (Tabela 'clients') ---
  const [formData, setFormData] = useState<any>({
    nome: "",
    sexo: "Masculino",
    analfabeto: false,
    cpf: "",
    data_nascimento: "",
    naturalidade: "",
    nacionalidade: "Brasileiro(a)",
    profissao: "Agricultor(a)",
    capacidade_civil: "Plena", 
    rep_nome: "", rep_cpf: "", rep_rg: "", rep_parentesco: "", rep_endereco: "", rep_telefone: "",
    rg: "", orgao_expedidor: "", data_expedicao: "", nit: "", ctps: "", senha_meu_inss: "",
    nome_mae: "", nome_pai: "", estado_civil: "Solteiro(a)", nome_conjuge: "", cpf_conjuge: "",
    cep: "", endereco: "", bairro: "", cidade: "", telefone: "", telefone_recado: "",
    resumo_cnis: "", historico_beneficios: "",
    possui_cnpj: false, detalhes_cnpj: "",
    possui_outra_renda: false, detalhes_renda: "",
    endereco_divergente: false, justificativa_endereco: "",
    personal_docs: [], // Preservado para não apagar dados do GED
    status_processo: "A Iniciar"
  });

  // --- ESTADO 2: DADOS RURAIS (Tabela 'interviews') ---
  const [ruralData, setRuralData] = useState<any>({
    nome_imovel: "", itr_nirf: "", area_total: "", area_util: "", municipio_uf: "",
    condicao_posse: "proprietario", outorgante_nome: "", outorgante_cpf: "",
    culturas: "", animais: "", destinacao: "subsistencia_venda", locais_venda: "",
    tem_empregados: "nao", tempo_empregados: "", grupo_familiar: ""
  });
  const [historico, setHistorico] = useState(""); // Narrativa
  const [timeline, setTimeline] = useState<any[]>([]); // Preservado para não apagar docs da ficha

  useEffect(() => {
    if (clienteId) loadFullData();
  }, [clienteId]);

  // Calcula idade automaticamente
  useEffect(() => {
    if (formData.data_nascimento) {
      const hoje = new Date();
      const nasc = new Date(formData.data_nascimento);
      let idadeCalc = hoje.getFullYear() - nasc.getFullYear();
      const m = hoje.getMonth() - nasc.getMonth();
      if (m < 0 || (m === 0 && hoje.getDate() < nasc.getDate())) {
        idadeCalc--;
      }
      setIdade(idadeCalc);
    } else {
      setIdade(null);
    }
  }, [formData.data_nascimento]);

  const loadFullData = async () => {
    setLoading(true);
    try {
      // 1. Carrega Cliente
      const { data: clientData, error: clientError } = await supabase
        .from('clients')
        .select('*')
        .eq('id', clienteId)
        .single();

      if (clientError) throw clientError;
      if (clientData) {
        setFormData({
          ...clientData,
          // Garante valores padrão para evitar inputs 'uncontrolled'
          nome: clientData.nome || "",
          sexo: clientData.sexo || "Masculino",
          analfabeto: clientData.analfabeto || false,
          cpf: clientData.cpf || "",
          data_nascimento: clientData.data_nascimento || "",
          naturalidade: clientData.naturalidade || "",
          nacionalidade: clientData.nacionalidade || "Brasileiro(a)",
          profissao: clientData.profissao || "Agricultor(a)",
          capacidade_civil: clientData.capacidade_civil || "Plena",
          // ... outros campos essenciais
          personal_docs: clientData.personal_docs || []
        });
      }

      // 2. Carrega Entrevista (Dados Rurais)
      const { data: interviewData } = await supabase
        .from('interviews')
        .select('*')
        .eq('client_id', clienteId)
        .maybeSingle();

      if (interviewData) {
        setHistorico(interviewData.historico_locais || "");
        if (Array.isArray(interviewData.timeline_json)) {
          setTimeline(interviewData.timeline_json);
        }
        if (interviewData.dados_rurais) {
          setRuralData((prev: any) => ({ ...prev, ...interviewData.dados_rurais }));
        }
      }

    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    } finally {
      setLoading(false);
    }
  };

  // --- HANDLERS ---
  const mascaraCPF = (v: string) => v.replace(/\D/g, '').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d)/, '$1.$2').replace(/(\d{3})(\d{1,2})/, '$1-$2').replace(/(-\d{2})\d+?$/, '$1');
  const mascaraTelefone = (v: string) => { v = v.replace(/\D/g, ""); v = v.replace(/^(\d{2})(\d)/g, "($1) $2"); v = v.replace(/(\d)(\d{4})$/, "$1-$2"); return v.substring(0, 15); };
  const mascaraCEP = (v: string) => v.replace(/\D/g, '').replace(/^(\d{5})(\d)/, '$1-$2').substring(0, 9);

  const handleCivilChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    let { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;
    
    if (name === 'cpf' || name === 'cpf_conjuge' || name === 'rep_cpf') value = mascaraCPF(value);
    if (name === 'telefone' || name === 'telefone_recado' || name === 'rep_telefone') value = mascaraTelefone(value);
    if (name === 'cep') value = mascaraCEP(value);

    setFormData((prev: any) => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
  };

  const handleRuralChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setRuralData({ ...ruralData, [e.target.name]: e.target.value });
  };

  const handleBlurCep = async () => {
    const cepLimpo = formData.cep.replace(/\D/g, '');
    if (cepLimpo.length === 8) {
      try {
        const res = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);
        const data = await res.json();
        if (!data.erro) {
          setFormData((prev: any) => ({
            ...prev,
            endereco: data.logradouro,
            bairro: data.bairro,
            cidade: `${data.localidade} - ${data.uf}`,
            naturalidade: prev.naturalidade || `${data.localidade} - ${data.uf}`
          }));
        }
      } catch (error) { console.error("Erro ao buscar CEP", error); }
    }
  };

  // --- SALVAR TUDO ---
  const handleSave = async () => {
    setLoading(true);
    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error("Sessão expirada. Faça login novamente.");

        // 1. Salva CLIENTE
        const clientPayload = { 
            ...formData,
            user_id: user.id,
            data_nascimento: formData.data_nascimento || null,
            data_expedicao: formData.data_expedicao || null,
        };

        if (clientPayload.capacidade_civil === "Plena") {
            clientPayload.rep_nome = ""; clientPayload.rep_cpf = ""; clientPayload.rep_rg = "";
            clientPayload.rep_parentesco = ""; clientPayload.rep_endereco = ""; clientPayload.rep_telefone = "";
        }

        let currentClientId = clienteId;

        if (currentClientId) {
            const { error } = await supabase.from('clients').update(clientPayload).eq('id', currentClientId);
            if (error) throw error;
        } else {
            const { data, error } = await supabase.from('clients').insert(clientPayload).select().single();
            if (error) throw error;
            currentClientId = data.id;
        }

        // 2. Salva FICHA RURAL (Entrevista)
        if (currentClientId) {
            const { error: interviewError } = await supabase.from('interviews').upsert({
                client_id: currentClientId,
                historico_locais: historico,
                timeline_json: timeline, // Mantém os documentos antigos
                dados_rurais: ruralData,
                updated_at: new Date()
            }, { onConflict: 'client_id' });

            if (interviewError) throw interviewError;
        }

        alert("Dados salvos com sucesso!");
        onBack();

    } catch (error: any) {
        if (error.message.includes("cpf_unico_por_advogado")) {
             alert("ERRO: CPF já cadastrado.");
        } else {
             alert("Erro ao salvar: " + error.message);
        }
    } finally {
        setLoading(false);
    }
  };

  const isRgAntigo = () => {
    if (!formData.data_expedicao) return false;
    const expedicao = new Date(formData.data_expedicao);
    const hoje = new Date();
    return (hoje.getFullYear() - expedicao.getFullYear()) >= 10;
  };

  const isIncapaz = formData.capacidade_civil !== "Plena";

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      <header className="bg-white border-b p-4 sticky top-0 z-20 shadow-sm flex justify-between items-center">
        <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 hover:bg-slate-100 rounded-full transition"><ArrowLeft className="text-slate-600"/></button>
            <div>
                <h1 className="text-xl font-bold text-slate-800">{clienteId ? "Editar Cadastro" : "Novo Cliente"}</h1>
                <p className="text-xs text-slate-500 font-medium">Dossiê Completo</p>
            </div>
        </div>
        
        <div className="flex gap-2">
            <button onClick={handleSave} disabled={loading} className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2 rounded-lg font-bold shadow flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50">
                <Save size={18}/> {loading ? "Salvando..." : "Salvar Tudo"}
            </button>
        </div>
      </header>

      {/* --- NAVEGAÇÃO DE ABAS --- */}
      <div className="bg-white border-b px-4 flex gap-6 sticky top-[73px] z-10">
          <button 
            onClick={() => setActiveTab('civil')}
            className={`py-3 text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'civil' ? 'border-emerald-500 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
          >
            <User size={18}/> Dados Civis
          </button>
          <button 
            onClick={() => setActiveTab('rural')}
            className={`py-3 text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${activeTab === 'rural' ? 'border-emerald-500 text-emerald-700' : 'border-transparent text-slate-500 hover:text-slate-700'}`}
          >
            <Tractor size={18}/> Ficha Rural
          </button>
      </div>

      <main className="flex-1 overflow-y-auto p-4 md:p-8 max-w-5xl mx-auto w-full space-y-8 pb-32">
        
        {/* ================= ABA 1: CIVIL ================= */}
        {activeTab === 'civil' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-left-4 duration-300">
                
                {/* 1. IDENTIFICAÇÃO CIVIL */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h2 className="text-lg font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2">
                        <User className="text-emerald-500"/> 1. Identificação Civil
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="col-span-1 md:col-span-2">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Nome Completo</label>
                            <input name="nome" value={formData.nome} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-emerald-500 transition-colors" placeholder="Nome do Segurado"/>
                        </div>
                        
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1 flex items-center gap-1">
                                Capacidade Civil {isIncapaz && <AlertTriangle size={12} className="text-amber-500"/>}
                            </label>
                            <select 
                                name="capacidade_civil" 
                                value={formData.capacidade_civil} 
                                onChange={handleCivilChange} 
                                className={`w-full border rounded-lg p-3 text-sm outline-none font-bold transition-colors cursor-pointer ${isIncapaz ? 'border-amber-400 bg-amber-50 text-amber-800' : 'border-slate-300'}`}
                            >
                                <option value="Plena">Plena (Padrão)</option>
                                <option value="Relativamente Incapaz">Relativamente Incapaz (16-18)</option>
                                <option value="Absolutamente Incapaz">Absolutamente Incapaz (Menor/Curatelado)</option>
                            </select>
                        </div>

                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">CPF</label>
                            <input name="cpf" value={formData.cpf} onChange={handleCivilChange} maxLength={14} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-emerald-500" placeholder="000.000.000-00"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1 flex justify-between">
                                Data de Nascimento
                                {idade !== null && <span className="text-emerald-600 font-black">{idade} Anos</span>}
                            </label>
                            <input type="date" name="data_nascimento" value={formData.data_nascimento} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-emerald-500"/>
                        </div>
                        
                        {/* --- CAMPO SEXO --- */}
                        <div>
                            <label className="text-xs font-bold text-emerald-600 uppercase ml-1">Sexo (Crucial p/ IA)</label>
                            <select name="sexo" value={formData.sexo} onChange={handleCivilChange} className="w-full border-2 border-emerald-100 bg-emerald-50 text-emerald-900 font-bold rounded-lg p-3 text-sm outline-none focus:border-emerald-500 cursor-pointer">
                                <option value="Masculino">Masculino</option>
                                <option value="Feminino">Feminino</option>
                            </select>
                        </div>

                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Naturalidade (Cidade-UF)</label>
                            <input name="naturalidade" value={formData.naturalidade} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-emerald-500"/>
                        </div>
                        <div className="col-span-1 md:col-span-1">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Nacionalidade</label>
                            <input name="nacionalidade" value={formData.nacionalidade} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-emerald-500"/>
                        </div>
                        <div className="col-span-1 md:col-span-1">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Profissão Atual</label>
                            <input name="profissao" value={formData.profissao} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-emerald-500"/>
                        </div>

                        {/* --- CAMPO ANALFABETO / A ROGO --- */}
                        <div className="flex items-end">
                            <div className={`flex items-center gap-3 p-3 border rounded-lg w-full transition-colors cursor-pointer ${formData.analfabeto ? 'bg-amber-50 border-amber-300' : 'bg-slate-50 border-slate-200'}`}>
                                <input type="checkbox" id="analfabeto" name="analfabeto" checked={formData.analfabeto} onChange={handleCivilChange} className="w-5 h-5 text-amber-600 rounded focus:ring-amber-500 accent-amber-500"/>
                                <label htmlFor="analfabeto" className={`text-sm font-bold cursor-pointer select-none flex items-center gap-2 ${formData.analfabeto ? 'text-amber-800' : 'text-slate-600'}`}>
                                <PenTool size={16}/> Não Assina / Analfabeto
                                </label>
                            </div>
                        </div>

                    </div>
                </section>

                {/* --- SEÇÃO DO REPRESENTANTE LEGAL (CONDICIONAL) --- */}
                {isIncapaz && (
                    <section className="bg-amber-50 p-6 rounded-2xl shadow-sm border border-amber-200">
                        <h2 className="text-lg font-bold text-amber-800 mb-6 flex items-center gap-2 border-b border-amber-200 pb-2">
                            <Shield className="text-amber-600"/> Dados do Representante Legal
                        </h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            <div className="col-span-1 md:col-span-2">
                                <label className="text-xs font-bold text-amber-700/70 uppercase ml-1">Nome do Representante</label>
                                <input name="rep_nome" value={formData.rep_nome} onChange={handleCivilChange} className="w-full border border-amber-300 bg-white rounded-lg p-3 text-sm outline-none focus:border-amber-500"/>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-amber-700/70 uppercase ml-1">Vínculo</label>
                                <select name="rep_parentesco" value={formData.rep_parentesco} onChange={handleCivilChange} className="w-full border border-amber-300 bg-white rounded-lg p-3 text-sm outline-none">
                                    <option value="">Selecione...</option>
                                    <option value="Mãe">Mãe</option>
                                    <option value="Pai">Pai</option>
                                    <option value="Tutor">Tutor</option>
                                    <option value="Curador">Curador</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-amber-700/70 uppercase ml-1">CPF Rep.</label>
                                <input name="rep_cpf" value={formData.rep_cpf} onChange={handleCivilChange} maxLength={14} className="w-full border border-amber-300 bg-white rounded-lg p-3 text-sm outline-none focus:border-amber-500"/>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-amber-700/70 uppercase ml-1">RG Rep.</label>
                                <input name="rep_rg" value={formData.rep_rg} onChange={handleCivilChange} className="w-full border border-amber-300 bg-white rounded-lg p-3 text-sm outline-none focus:border-amber-500"/>
                            </div>
                            <div>
                                <label className="text-xs font-bold text-amber-700/70 uppercase ml-1">Telefone Rep.</label>
                                <input name="rep_telefone" value={formData.rep_telefone} onChange={handleCivilChange} maxLength={15} className="w-full border border-amber-300 bg-white rounded-lg p-3 text-sm outline-none focus:border-amber-500"/>
                            </div>
                            <div className="col-span-1 md:col-span-3">
                                <label className="text-xs font-bold text-amber-700/70 uppercase ml-1">Endereço Rep.</label>
                                <input name="rep_endereco" value={formData.rep_endereco} onChange={handleCivilChange} className="w-full border border-amber-300 bg-white rounded-lg p-3 text-sm outline-none focus:border-amber-500"/>
                            </div>
                        </div>
                    </section>
                )}

                {/* 2. DOCUMENTAÇÃO & SENHAS */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h2 className="text-lg font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2">
                        <FileText className="text-blue-500"/> 2. Documentação & Senhas
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">RG (Número)</label>
                            <input name="rg" value={formData.rg} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-blue-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Órgão Exp.</label>
                            <input name="orgao_expedidor" value={formData.orgao_expedidor} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-blue-500"/>
                        </div>
                        <div className="relative">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1 flex justify-between">
                                Data Expedição
                                {isRgAntigo() && <span className="text-red-500 font-bold flex items-center gap-1"><AlertTriangle size={10}/> Antigo</span>}
                            </label>
                            <input type="date" name="data_expedicao" value={formData.data_expedicao} onChange={handleCivilChange} className={`w-full border rounded-lg p-3 text-sm outline-none focus:border-blue-500 ${isRgAntigo() ? 'border-red-300 bg-red-50 text-red-800' : 'border-slate-300'}`}/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">NIT / PIS</label>
                            <input name="nit" value={formData.nit} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-blue-500"/>
                        </div>
                        <div className="md:col-span-2">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">CTPS</label>
                            <input name="ctps" value={formData.ctps} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-blue-500"/>
                        </div>
                        <div className="md:col-span-2">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1 text-emerald-600">Senha Meu INSS</label>
                            <input name="senha_meu_inss" value={formData.senha_meu_inss} onChange={handleCivilChange} className="w-full border border-emerald-200 bg-emerald-50 rounded-lg p-3 text-sm outline-none focus:border-emerald-500 text-emerald-800 font-medium" placeholder="Digite a senha..."/>
                        </div>
                    </div>
                </section>

                {/* 3. FAMÍLIA */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h2 className="text-lg font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2">
                        <Users className="text-purple-500"/> 3. Família
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Mãe</label>
                            <input name="nome_mae" value={formData.nome_mae} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-purple-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Pai</label>
                            <input name="nome_pai" value={formData.nome_pai} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-purple-500"/>
                        </div>
                    
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Estado Civil</label>
                            <select name="estado_civil" value={formData.estado_civil} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none bg-white">
                                <option>Solteiro(a)</option>
                                <option>Casado(a)</option>
                                <option>Divorciado(a)</option>
                                <option>Viúvo(a)</option>
                                <option>União Estável</option>
                            </select>
                        </div>
                        {(formData.estado_civil === "Casado(a)" || formData.estado_civil === "União Estável" || formData.estado_civil === "Viúvo(a)") && (
                            <>
                                <div className="animate-in fade-in slide-in-from-top-2">
                                    <label className="text-xs font-bold text-purple-600 uppercase ml-1">Cônjuge</label>
                                    <input name="nome_conjuge" value={formData.nome_conjuge} onChange={handleCivilChange} className="w-full border border-purple-200 bg-purple-50 rounded-lg p-3 text-sm outline-none focus:border-purple-500"/>
                                </div>
                                <div className="animate-in fade-in slide-in-from-top-2">
                                    <label className="text-xs font-bold text-purple-600 uppercase ml-1">CPF Cônjuge</label>
                                    <input name="cpf_conjuge" value={formData.cpf_conjuge} onChange={handleCivilChange} maxLength={14} className="w-full border border-purple-200 bg-purple-50 rounded-lg p-3 text-sm outline-none focus:border-purple-500"/>
                                </div>
                            </>
                        )}
                    </div>
                </section>

                {/* 4. CONTATO & LOCALIZAÇÃO */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h2 className="text-lg font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2">
                        <MapPin className="text-orange-500"/> 4. Contato & Localização
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">CEP</label>
                            <input name="cep" value={formData.cep} onChange={handleCivilChange} onBlur={handleBlurCep} maxLength={9} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-orange-500"/>
                        </div>
                        <div className="md:col-span-3">
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Endereço</label>
                            <input name="endereco" value={formData.endereco} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-orange-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Bairro</label>
                            <input name="bairro" value={formData.bairro} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-orange-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Cidade - UF</label>
                            <input name="cidade" value={formData.cidade} onChange={handleCivilChange} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-orange-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1 flex items-center gap-1"><Phone size={12}/> Telefone</label>
                            <input name="telefone" value={formData.telefone} onChange={handleCivilChange} maxLength={15} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-orange-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1 flex items-center gap-1"><Phone size={12}/> Recado</label>
                            <input name="telefone_recado" value={formData.telefone_recado} onChange={handleCivilChange} maxLength={15} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-orange-500"/>
                        </div>
                    </div>
                </section>

                {/* 5. ANÁLISE PREVIDENCIÁRIA & IMPEDIMENTOS */}
                <section className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h2 className="text-lg font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2">
                        <Briefcase className="text-red-500"/> 5. Análise & Impedimentos (Rural)
                    </h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Vínculos Urbanos (CNIS)</label>
                            <textarea name="resumo_cnis" value={formData.resumo_cnis} onChange={handleCivilChange} rows={3} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-red-500"/>
                        </div>
                        <div>
                            <label className="text-xs font-bold text-slate-500 uppercase ml-1">Histórico de Benefícios</label>
                            <textarea name="historico_beneficios" value={formData.historico_beneficios} onChange={handleCivilChange} rows={3} className="w-full border border-slate-300 rounded-lg p-3 text-sm outline-none focus:border-red-500"/>
                        </div>
                    </div>
                
                    <div className="space-y-4 bg-slate-50 p-4 rounded-xl border border-slate-100">
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <input type="checkbox" id="cnpj" name="possui_cnpj" checked={formData.possui_cnpj} onChange={handleCivilChange} className="w-5 h-5 text-red-600 rounded focus:ring-red-500"/>
                                <label htmlFor="cnpj" className="font-bold text-slate-700 text-sm">Possui CNPJ / MEI?</label>
                            </div>
                            {formData.possui_cnpj && (
                                <input name="detalhes_cnpj" value={formData.detalhes_cnpj} onChange={handleCivilChange} className="w-full border border-red-300 bg-red-50 rounded-lg p-2 text-sm outline-none focus:border-red-500 ml-7 w-[calc(100%-1.75rem)]"/>
                            )}
                        </div>
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <input type="checkbox" id="renda" name="possui_outra_renda" checked={formData.possui_outra_renda} onChange={handleCivilChange} className="w-5 h-5 text-red-600 rounded focus:ring-red-500"/>
                                <label htmlFor="renda" className="font-bold text-slate-700 text-sm">Outras Rendas?</label>
                            </div>
                            {formData.possui_outra_renda && (
                                <input name="detalhes_renda" value={formData.detalhes_renda} onChange={handleCivilChange} className="w-full border border-red-300 bg-red-50 rounded-lg p-2 text-sm outline-none focus:border-red-500 ml-7 w-[calc(100%-1.75rem)]"/>
                            )}
                        </div>
                        <div>
                            <div className="flex items-center gap-2 mb-2">
                                <input type="checkbox" id="endereco_div" name="endereco_divergente" checked={formData.endereco_divergente} onChange={handleCivilChange} className="w-5 h-5 text-red-600 rounded focus:ring-red-500"/>
                                <label htmlFor="endereco_div" className="font-bold text-slate-700 text-sm">Endereço Divergente?</label>
                            </div>
                            {formData.endereco_divergente && (
                                <input name="justificativa_endereco" value={formData.justificativa_endereco} onChange={handleCivilChange} className="w-full border border-red-300 bg-red-50 rounded-lg p-2 text-sm outline-none focus:border-red-500 ml-7 w-[calc(100%-1.75rem)]"/>
                            )}
                        </div>
                    </div>
                </section>
            </div>
        )}

        {/* ================= ABA 2: RURAL & NARRATIVA ================= */}
        {activeTab === 'rural' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                     <h3 className="font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2"><LayoutList size={20} className="text-emerald-500"/> Caracterização do Imóvel</h3>
                     
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Nome do Imóvel</label><input name="nome_imovel" value={ruralData.nome_imovel} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Município / UF</label><input name="municipio_uf" value={ruralData.municipio_uf} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">ITR / NIRF / CCIR</label><input name="itr_nirf" value={ruralData.itr_nirf} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                        
                        <div className="grid grid-cols-2 gap-4">
                            <div><label className="text-xs font-bold text-slate-500 mb-1 block">Área Total (Ha)</label><input name="area_total" value={ruralData.area_total} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                            <div>
                                <label className="text-xs font-bold text-slate-500 mb-1 block">Condição de Posse</label>
                                <div className="relative">
                                    <select name="condicao_posse" value={ruralData.condicao_posse} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm appearance-none bg-white">
                                        <option value="proprietario">Proprietário</option>
                                        <option value="posseiro">Posseiro</option>
                                        <option value="arrendatario">Arrendatário</option>
                                        <option value="parceiro">Parceiro / Meeiro</option>
                                        <option value="comodatario">Comodatário</option>
                                        <option value="assentado">Assentado</option>
                                    </select>
                                    <ChevronRight size={14} className="absolute right-3 top-3.5 rotate-90 text-slate-400 pointer-events-none"/>
                                </div>
                            </div>
                        </div>
                     </div>

                     {!['proprietario', 'posseiro'].includes(ruralData.condicao_posse) && (
                        <div className="mt-4 p-4 bg-amber-50 rounded-xl border border-amber-100">
                            <h4 className="font-bold text-amber-800 text-sm mb-2">Dados do Proprietário</h4>
                            <div className="grid grid-cols-2 gap-4">
                                <div><label className="text-xs font-bold text-amber-700/70 mb-1 block">Nome do Dono</label><input name="outorgante_nome" value={ruralData.outorgante_nome} onChange={handleRuralChange} className="w-full p-2 border border-amber-200 rounded text-sm"/></div>
                                <div><label className="text-xs font-bold text-amber-700/70 mb-1 block">CPF do Dono</label><input name="outorgante_cpf" value={ruralData.outorgante_cpf} onChange={handleRuralChange} className="w-full p-2 border border-amber-200 rounded text-sm"/></div>
                            </div>
                        </div>
                     )}
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-700 mb-6 flex items-center gap-2 border-b pb-2"><ShoppingBag size={20} className="text-emerald-500"/> Produção & Família</h3>
                    <div className="space-y-4">
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">O que produz/cria?</label><textarea name="culturas" rows={2} value={ruralData.culturas} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                        <div><label className="text-xs font-bold text-slate-500 mb-1 block">Grupo Familiar (Quem ajuda?)</label><textarea name="grupo_familiar" rows={2} value={ruralData.grupo_familiar} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div><label className="text-xs font-bold text-slate-500 mb-1 block">Onde vende?</label><input name="locais_venda" value={ruralData.locais_venda} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                            <div className="grid grid-cols-2 gap-4">
                                <div>
                                    <label className="text-xs font-bold text-slate-500 mb-1 block">Tem Empregados?</label>
                                    <select name="tem_empregados" value={ruralData.tem_empregados} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm bg-white">
                                        <option value="nao">Não</option>
                                        <option value="sim">Sim (Temp.)</option>
                                        <option value="sim_permanente">Sim (Perm.)</option>
                                    </select>
                                </div>
                                {ruralData.tem_empregados !== 'nao' && (
                                    <div><label className="text-xs font-bold text-slate-500 mb-1 block">Tempo?</label><input name="tempo_empregados" value={ruralData.tempo_empregados} onChange={handleRuralChange} className="w-full p-3 border rounded-lg text-sm"/></div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 className="font-bold text-slate-700 mb-4 flex items-center gap-2 border-b pb-2"><FileText size={20} className="text-blue-500"/> Narrativa Fática</h3>
                    <textarea 
                        className="w-full h-64 p-4 border rounded-xl outline-none text-sm leading-relaxed resize-none focus:border-blue-500 transition-colors"
                        placeholder="Escreva a história de vida rural do cliente aqui..."
                        value={historico}
                        onChange={e => setHistorico(e.target.value)}
                    />
                </div>

            </div>
        )}

      </main>
    </div>
  );
}